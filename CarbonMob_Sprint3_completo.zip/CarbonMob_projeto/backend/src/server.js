const bcrypt = require("bcryptjs");
const express = require("express");
const cors = require("cors");
const mysql = require("mysql2/promise");
const fs = require("fs");
const path = require("path");
require("dotenv").config();

const app = express();

app.use(cors());
app.use(express.json());

const pool = mysql.createPool({
  host: process.env.DB_HOST || "localhost",
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME || "carbonmob",
  waitForConnections: true,
  connectionLimit: 10
});

const fatores = JSON.parse(
  fs.readFileSync(
    path.join(__dirname, "../../data/emission_factors.json"),
    "utf8"
  )
);

app.get("/", (req, res) => {
  res.json({
    sistema: "CarbonMob",
    status: "online"
  });
});

function calcularEmissao({ distancia, transporte, combustivel, consumo }) {
  const dist = Number(distancia);
  if (!Number.isFinite(dist) || dist <= 0) {
    throw new Error("Informe uma distância válida (maior que zero).");
  }

  if (transporte === "a_pe" || transporte === "bicicleta") {
    return { combustivel_gasto: 0, emissao_kg: 0, fator_emissao: 0 };
  }

  // Transportes calculados por km (público, elétrico)
  if (fatores.transportes_por_km && transporte in fatores.transportes_por_km) {
    const fatorKm = fatores.transportes_por_km[transporte].fator_emissao;
    if (fatorKm === null || fatorKm === undefined) {
      throw new Error("O fator de emissão desse transporte ainda não foi configurado.");
    }
    return {
      combustivel_gasto: 0,
      emissao_kg: Number((dist * Number(fatorKm)).toFixed(3)),
      fator_emissao: Number(fatorKm)
    };
  }

  // Transportes a combustão (carro, moto)
  if (!combustivel || !consumo || Number(consumo) <= 0) {
    throw new Error("Informe combustível e consumo do veículo.");
  }

  const fator = fatores.combustiveis[combustivel]?.fator_emissao;
  if (fator === null || fator === undefined) {
    throw new Error("O fator de emissão desse combustível ainda não foi configurado.");
  }

  const combustivelGasto = dist / Number(consumo);
  const emissao = combustivelGasto * Number(fator);

  return {
    combustivel_gasto: Number(combustivelGasto.toFixed(3)),
    emissao_kg: Number(emissao.toFixed(3)),
    fator_emissao: Number(fator)
  };
}

app.post("/api/emissoes/calcular", (req, res) => {
  try {
    const { distancia, transporte, combustivel, consumo } = req.body;

    if (distancia === undefined || !transporte) {
      return res.status(400).json({
        erro: "Informe distância e transporte."
      });
    }

    const resultado = calcularEmissao({
      distancia,
      transporte,
      combustivel,
      consumo
    });

    res.json({
      distancia_km: Number(distancia),
      transporte,
      combustivel: combustivel || null,
      consumo_km_l: consumo || null,
      ...resultado
    });
  } catch (error) {
    res.status(400).json({ erro: error.message });
  }
});

app.post("/api/usuarios", async (req, res) => {
  const nome = String(req.body.nome || "").trim();
  const email = String(req.body.email || "").trim().toLowerCase();
  const senha = req.body.senha;
  if (!nome || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || typeof senha !== "string" || senha.length < 8 || Buffer.byteLength(senha, "utf8") > 72) {
    return res.status(400).json({ erro: "Informe nome, e-mail válido e senha de 8 a 72 bytes." });
  }
  try {
    const hash = await bcrypt.hash(senha, 12);
    const [result] = await pool.query(
      "INSERT INTO usuarios (nome, email, senha) VALUES (?, ?, ?)", [nome, email, hash]
    );
    res.status(201).json({ id: result.insertId, nome, email });
  } catch (error) {
    if (error.code === "ER_DUP_ENTRY") return res.status(409).json({ erro: "E-mail já cadastrado." });
    console.error(error);
    res.status(500).json({ erro: "Não foi possível cadastrar agora." });
  }
});

app.post("/api/login", async (req, res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const senha = req.body.senha;
  if (!email || typeof senha !== "string") return res.status(400).json({ erro: "Informe e-mail e senha." });
  try {
    const [rows] = await pool.query("SELECT id, nome, email, senha FROM usuarios WHERE email = ?", [email]);
    const usuario = rows[0];
    // Registros antigos em texto simples não são aceitos: devem redefinir a senha.
    const valido = usuario && usuario.senha.startsWith("$2") && await bcrypt.compare(senha, usuario.senha);
    if (!valido) return res.status(401).json({ erro: "E-mail ou senha inválidos. Contas antigas precisam redefinir a senha." });
    res.json({ id: usuario.id, nome: usuario.nome, email: usuario.email });
  } catch (error) {
    console.error(error);
    res.status(500).json({ erro: "Não foi possível entrar agora." });
  }
});

app.post("/api/deslocamentos", async (req, res) => {
  try {
    const { usuario_id, origem, destino, distancia, tempo_minutos,
            transporte, combustivel, consumo } = req.body;

    if (!Number.isInteger(Number(usuario_id)) || !origem || !destino ||
        !Number.isFinite(Number(tempo_minutos)) || !transporte) {
      return res.status(400).json({ erro: "Dados do deslocamento incompletos." });
    }

    const [u] = await pool.query("SELECT id FROM usuarios WHERE id = ?", [usuario_id]);
    if (!u.length) return res.status(400).json({ erro: "Usuário não encontrado. Faça login novamente." });

    const resultado = calcularEmissao({ distancia, transporte, combustivel, consumo });

    const [insert] = await pool.query(
      `INSERT INTO deslocamentos
      (usuario_id, origem, destino, distancia_km, tempo_minutos,
       transporte, combustivel, consumo_km_l, combustivel_gasto_l, emissao_kg)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [usuario_id, origem, destino, distancia, tempo_minutos, transporte,
       combustivel || null, consumo || null,
       resultado.combustivel_gasto, resultado.emissao_kg]
    );

    res.status(201).json({ id: insert.insertId, ...resultado });
  } catch (error) {
    console.error(error);
    res.status(400).json({ erro: error.message });
  }
});

// Card 43 + 50: editar deslocamento e recalcular emissão
app.put("/api/deslocamentos/:id", async (req, res) => {
  try {
    const { usuario_id, origem, destino, distancia, tempo_minutos } = req.body;
    const [rows] = await pool.query(
      "SELECT * FROM deslocamentos WHERE id = ? AND usuario_id = ?",
      [req.params.id, usuario_id]
    );
    const atual = rows[0];
    if (!atual) return res.status(404).json({ erro: "Deslocamento não encontrado." });

    const novaOrigem = origem || atual.origem;
    const novoDestino = destino || atual.destino;
    const novaDistancia = distancia ?? atual.distancia_km;
    const novoTempo = tempo_minutos ?? atual.tempo_minutos;

    const resultado = calcularEmissao({
      distancia: novaDistancia,
      transporte: atual.transporte,
      combustivel: atual.combustivel,
      consumo: atual.consumo_km_l
    });

    await pool.query(
      `UPDATE deslocamentos
       SET origem = ?, destino = ?, distancia_km = ?, tempo_minutos = ?,
           combustivel_gasto_l = ?, emissao_kg = ?
       WHERE id = ? AND usuario_id = ?`,
      [novaOrigem, novoDestino, novaDistancia, novoTempo,
       resultado.combustivel_gasto, resultado.emissao_kg,
       req.params.id, usuario_id]
    );

    res.json({ id: Number(req.params.id), ...resultado });
  } catch (error) {
    console.error(error);
    res.status(400).json({ erro: error.message });
  }
});

// Card 42: excluir deslocamento
app.delete("/api/deslocamentos/:id", async (req, res) => {
  try {
    const [r] = await pool.query(
      "DELETE FROM deslocamentos WHERE id = ? AND usuario_id = ?",
      [req.params.id, req.query.usuario_id]
    );
    if (!r.affectedRows) return res.status(404).json({ erro: "Deslocamento não encontrado." });
    res.json({ ok: true });
  } catch (error) {
    console.error(error);
    res.status(500).json({ erro: "Não foi possível excluir." });
  }
});

app.get("/api/deslocamentos/:usuarioId", async (req, res) => {
  try {
    const { transporte, de, ate } = req.query;
    const where = ["usuario_id = ?"];
    const params = [req.params.usuarioId];
    if (transporte) { where.push("transporte = ?"); params.push(transporte); }
    if (de) { where.push("DATE(data_deslocamento) >= ?"); params.push(de); }
    if (ate) { where.push("DATE(data_deslocamento) <= ?"); params.push(ate); }
    const [rows] = await pool.query(
      `SELECT * FROM deslocamentos WHERE ${where.join(" AND ")}
       ORDER BY data_deslocamento DESC`, params);
    res.json(rows);
  } catch (error) {
    res.status(500).json({ erro: error.message });
  }
});

// Card 12: detalhe de um deslocamento
app.get("/api/deslocamento/:id", async (req, res) => {
  try {
    const [rows] = await pool.query(
      "SELECT * FROM deslocamentos WHERE id = ? AND usuario_id = ?",
      [req.params.id, req.query.usuario_id]);
    if (!rows.length) return res.status(404).json({ erro: "Deslocamento não encontrado." });
    res.json(rows[0]);
  } catch (error) {
    res.status(500).json({ erro: error.message });
  }
});

app.get("/api/impacto/:usuarioId", async (req, res) => {
  try {
    const [total] = await pool.query(
      `SELECT
       COALESCE(SUM(emissao_kg), 0) AS total_emissao,
       COUNT(*) AS total_deslocamentos,
       COALESCE(AVG(emissao_kg), 0) AS media_emissao
       FROM deslocamentos
       WHERE usuario_id = ?`,
      [req.params.usuarioId]
    );

    const [mensal] = await pool.query(
      `SELECT
       DATE_FORMAT(data_deslocamento, '%Y-%m') AS mes,
       SUM(emissao_kg) AS emissao
       FROM deslocamentos
       WHERE usuario_id = ?
       GROUP BY DATE_FORMAT(data_deslocamento, '%Y-%m')
       ORDER BY mes`,
      [req.params.usuarioId]
    );

    res.json({
      resumo: total[0],
      mensal
    });
  } catch (error) {
    res.status(500).json({ erro: error.message });
  }
});

app.get("/api/creditos", async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT
        c.id,
        p.nome AS projeto,
        p.empresa,
        p.tipo,
        p.descricao,
        c.preco,
        c.compensacao_kg,
        c.quantidade_disponivel
      FROM creditos_carbono c
      INNER JOIN projetos_ambientais p ON p.id = c.projeto_id
      ORDER BY c.preco ASC
    `);

    res.json(rows);
  } catch (error) {
    res.status(500).json({ erro: error.message });
  }
});


// ================= SPRINT 2 e 3 =================

const VELOCIDADE_KMH = {
  a_pe: 5, bicicleta: 15, carro: 40, moto: 40,
  transporte_publico: 25, carro_eletrico: 40
}; // valores de referência provisórios para estimar o tempo
const NOMES_TRANSPORTE = {
  a_pe: "A pé", bicicleta: "Bicicleta", carro: "Carro", moto: "Moto",
  transporte_publico: "Transporte público", carro_eletrico: "Carro elétrico"
};

async function ensureSchema() {
  await pool.query(`CREATE TABLE IF NOT EXISTS compensacoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    credito_id INT NOT NULL,
    deslocamento_id INT NULL,
    quantidade INT NOT NULL,
    kg_compensado DECIMAL(10,2) NOT NULL,
    data_compensacao DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
    FOREIGN KEY (credito_id) REFERENCES creditos_carbono(id)
  )`);
  await pool.query(`CREATE TABLE IF NOT EXISTS metas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    mes CHAR(7) NOT NULL,
    meta_kg DECIMAL(10,2) NOT NULL,
    UNIQUE KEY uq_meta (usuario_id, mes),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
  )`);
  await pool.query(`CREATE TABLE IF NOT EXISTS notificacoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    assunto VARCHAR(150) NOT NULL,
    mensagem TEXT NOT NULL,
    enviado_email TINYINT NOT NULL DEFAULT 0,
    data_criacao DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
  )`);
  const [col] = await pool.query(
    `SELECT COUNT(*) AS n FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'creditos_carbono'
     AND COLUMN_NAME = 'vendedor_id'`);
  if (!col[0].n) {
    await pool.query("ALTER TABLE creditos_carbono ADD COLUMN vendedor_id INT NULL");
  }
}

// Card 44: notificação (guardada no banco e enviada por e-mail se o SMTP estiver configurado)
let mailer = null;
try {
  if (process.env.SMTP_HOST) {
    mailer = require("nodemailer").createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT || 587),
      auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
    });
  }
} catch (e) { console.warn("nodemailer não instalado; e-mails desativados."); }

async function notificar(usuarioId, assunto, mensagem) {
  let enviado = 0;
  try {
    if (mailer) {
      const [u] = await pool.query("SELECT email FROM usuarios WHERE id = ?", [usuarioId]);
      if (u.length) {
        await mailer.sendMail({
          from: process.env.SMTP_FROM || process.env.SMTP_USER,
          to: u[0].email, subject: `CarbonMob - ${assunto}`, text: mensagem
        });
        enviado = 1;
      }
    }
  } catch (e) { console.error("Falha ao enviar e-mail:", e.message); }
  try {
    await pool.query(
      "INSERT INTO notificacoes (usuario_id, assunto, mensagem, enviado_email) VALUES (?, ?, ?, ?)",
      [usuarioId, assunto, mensagem, enviado]);
  } catch (e) { console.error(e.message); }
}

// Card 41: alterar senha
app.put("/api/usuarios/:id/senha", async (req, res) => {
  const { senha_atual, nova_senha } = req.body;
  if (typeof nova_senha !== "string" || nova_senha.length < 8 ||
      Buffer.byteLength(nova_senha, "utf8") > 72) {
    return res.status(400).json({ erro: "A nova senha deve ter de 8 a 72 caracteres." });
  }
  try {
    const [rows] = await pool.query("SELECT senha FROM usuarios WHERE id = ?", [req.params.id]);
    if (!rows.length || !(await bcrypt.compare(String(senha_atual || ""), rows[0].senha))) {
      return res.status(401).json({ erro: "Senha atual incorreta." });
    }
    await pool.query("UPDATE usuarios SET senha = ? WHERE id = ?",
      [await bcrypt.hash(nova_senha, 12), req.params.id]);
    notificar(req.params.id, "Senha alterada", "A senha da sua conta foi alterada.");
    res.json({ ok: true });
  } catch (error) {
    console.error(error);
    res.status(500).json({ erro: "Não foi possível alterar a senha." });
  }
});

app.get("/api/notificacoes/:usuarioId", async (req, res) => {
  try {
    const [rows] = await pool.query(
      "SELECT * FROM notificacoes WHERE usuario_id = ? ORDER BY data_criacao DESC LIMIT 50",
      [req.params.usuarioId]);
    res.json(rows);
  } catch (error) { res.status(500).json({ erro: error.message }); }
});

// Card 07: comparar meios de transporte
app.post("/api/comparar-transportes", (req, res) => {
  const { distancia, combustivel, consumo } = req.body;
  const resultado = Object.keys(VELOCIDADE_KMH).map((t) => {
    const item = { transporte: t, nome: NOMES_TRANSPORTE[t],
      tempo_min: Math.round((Number(distancia) / VELOCIDADE_KMH[t]) * 60) };
    try {
      item.emissao_kg = calcularEmissao({ distancia, transporte: t, combustivel, consumo }).emissao_kg;
    } catch (e) {
      item.emissao_kg = null;
      item.motivo = e.message;
    }
    return item;
  });
  res.json(resultado);
});

// Cards 21/48: disponibilizar créditos e acompanhar os que estão à venda
app.post("/api/creditos", async (req, res) => {
  const { usuario_id, projeto, empresa, tipo, descricao, preco, compensacao_kg, quantidade } = req.body;
  if (!usuario_id || !projeto || !empresa || !tipo || !(Number(preco) > 0) ||
      !(Number(compensacao_kg) > 0) || !(Number(quantidade) > 0)) {
    return res.status(400).json({ erro: "Preencha todos os campos com valores válidos." });
  }
  try {
    const [p] = await pool.query(
      "INSERT INTO projetos_ambientais (nome, empresa, tipo, descricao) VALUES (?, ?, ?, ?)",
      [projeto, empresa, tipo, descricao || ""]);
    const [c] = await pool.query(
      `INSERT INTO creditos_carbono (projeto_id, preco, compensacao_kg, quantidade_disponivel, vendedor_id)
       VALUES (?, ?, ?, ?, ?)`, [p.insertId, preco, compensacao_kg, quantidade, usuario_id]);
    notificar(usuario_id, "Crédito disponibilizado", `Seu crédito "${projeto}" foi publicado na loja.`);
    res.status(201).json({ id: c.insertId });
  } catch (error) {
    console.error(error);
    res.status(500).json({ erro: "Não foi possível cadastrar o crédito." });
  }
});

app.get("/api/creditos/vendedor/:usuarioId", async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT c.id, p.nome AS projeto, p.tipo, c.preco, c.compensacao_kg,
             c.quantidade_disponivel,
             COALESCE((SELECT SUM(quantidade) FROM compras_creditos WHERE credito_id = c.id), 0) AS vendidos
      FROM creditos_carbono c
      JOIN projetos_ambientais p ON p.id = c.projeto_id
      WHERE c.vendedor_id = ? ORDER BY c.id DESC`, [req.params.usuarioId]);
    res.json(rows);
  } catch (error) { res.status(500).json({ erro: error.message }); }
});

// Cards 08/25: detalhe de um crédito
app.get("/api/creditos/:id", async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT c.id, p.nome AS projeto, p.empresa, p.tipo, p.descricao,
             c.preco, c.compensacao_kg, c.quantidade_disponivel
      FROM creditos_carbono c JOIN projetos_ambientais p ON p.id = c.projeto_id
      WHERE c.id = ?`, [req.params.id]);
    if (!rows.length) return res.status(404).json({ erro: "Crédito não encontrado." });
    res.json(rows[0]);
  } catch (error) { res.status(500).json({ erro: error.message }); }
});

// Card 10: simular créditos necessários
app.get("/api/simular", async (req, res) => {
  try {
    const emissao = Number(req.query.emissao_kg);
    if (!(emissao > 0)) return res.status(400).json({ erro: "Informe uma emissão maior que zero." });
    const [rows] = await pool.query(
      "SELECT preco, compensacao_kg FROM creditos_carbono WHERE id = ?", [req.query.credito_id]);
    if (!rows.length) return res.status(404).json({ erro: "Crédito não encontrado." });
    const unidades = Math.ceil(emissao / Number(rows[0].compensacao_kg));
    res.json({ unidades, valor_total: Number((unidades * Number(rows[0].preco)).toFixed(2)) });
  } catch (error) { res.status(500).json({ erro: error.message }); }
});

// Card 09: comprar créditos (pagamento simulado)
app.post("/api/compras", async (req, res) => {
  const { usuario_id, credito_id } = req.body;
  const quantidade = Number(req.body.quantidade);
  if (!usuario_id || !credito_id || !Number.isInteger(quantidade) || quantidade < 1) {
    return res.status(400).json({ erro: "Informe um crédito e uma quantidade inteira." });
  }
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const [rows] = await conn.query(
      "SELECT preco, quantidade_disponivel FROM creditos_carbono WHERE id = ? FOR UPDATE", [credito_id]);
    if (!rows.length) throw new Error("Crédito não encontrado.");
    if (rows[0].quantidade_disponivel < quantidade) throw new Error("Quantidade indisponível no estoque.");
    const total = Number((Number(rows[0].preco) * quantidade).toFixed(2));
    await conn.query(
      "UPDATE creditos_carbono SET quantidade_disponivel = quantidade_disponivel - ? WHERE id = ?",
      [quantidade, credito_id]);
    const [r] = await conn.query(
      "INSERT INTO compras_creditos (usuario_id, credito_id, quantidade, valor_total) VALUES (?, ?, ?, ?)",
      [usuario_id, credito_id, quantidade, total]);
    await conn.commit();
    notificar(usuario_id, "Compra realizada", `Compra #${r.insertId} de ${quantidade} crédito(s): R$ ${total.toFixed(2)}.`);
    res.status(201).json({ id: r.insertId, valor_total: total });
  } catch (error) {
    await conn.rollback();
    res.status(400).json({ erro: error.message });
  } finally { conn.release(); }
});

// Card 26: comprovante
app.get("/api/compras/detalhe/:id", async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT m.id, m.quantidade, m.valor_total, m.data_compra, u.nome AS comprador,
             p.nome AS projeto, p.empresa, c.preco, c.compensacao_kg
      FROM compras_creditos m
      JOIN usuarios u ON u.id = m.usuario_id
      JOIN creditos_carbono c ON c.id = m.credito_id
      JOIN projetos_ambientais p ON p.id = c.projeto_id
      WHERE m.id = ? AND m.usuario_id = ?`, [req.params.id, req.query.usuario_id]);
    if (!rows.length) return res.status(404).json({ erro: "Compra não encontrada." });
    res.json(rows[0]);
  } catch (error) { res.status(500).json({ erro: error.message }); }
});

// Card 29: histórico de compras
app.get("/api/compras/:usuarioId", async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT m.id, m.quantidade, m.valor_total, m.data_compra, p.nome AS projeto
      FROM compras_creditos m
      JOIN creditos_carbono c ON c.id = m.credito_id
      JOIN projetos_ambientais p ON p.id = c.projeto_id
      WHERE m.usuario_id = ? ORDER BY m.data_compra DESC`, [req.params.usuarioId]);
    res.json(rows);
  } catch (error) { res.status(500).json({ erro: error.message }); }
});

// Card 24: saldo de créditos por tipo de crédito
app.get("/api/saldo/:usuarioId", async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT c.id AS credito_id, p.nome AS projeto, c.compensacao_kg,
        COALESCE((SELECT SUM(quantidade) FROM compras_creditos WHERE usuario_id = ? AND credito_id = c.id), 0)
        - COALESCE((SELECT SUM(quantidade) FROM compensacoes WHERE usuario_id = ? AND credito_id = c.id), 0) AS saldo
      FROM creditos_carbono c JOIN projetos_ambientais p ON p.id = c.projeto_id
      HAVING saldo > 0`, [req.params.usuarioId, req.params.usuarioId]);
    res.json(rows);
  } catch (error) { res.status(500).json({ erro: error.message }); }
});

// Card 16: compensar emissões usando créditos
app.post("/api/compensacoes", async (req, res) => {
  const { usuario_id, credito_id, deslocamento_id } = req.body;
  const quantidade = Number(req.body.quantidade);
  if (!usuario_id || !credito_id || !Number.isInteger(quantidade) || quantidade < 1) {
    return res.status(400).json({ erro: "Informe o crédito e uma quantidade inteira." });
  }
  try {
    const [s] = await pool.query(`
      SELECT c.compensacao_kg,
        COALESCE((SELECT SUM(quantidade) FROM compras_creditos WHERE usuario_id = ? AND credito_id = c.id), 0)
        - COALESCE((SELECT SUM(quantidade) FROM compensacoes WHERE usuario_id = ? AND credito_id = c.id), 0) AS saldo
      FROM creditos_carbono c WHERE c.id = ?`, [usuario_id, usuario_id, credito_id]);
    if (!s.length || s[0].saldo < quantidade) {
      return res.status(400).json({ erro: "Você não tem créditos suficientes." });
    }
    const kg = Number((quantidade * Number(s[0].compensacao_kg)).toFixed(2));
    const [r] = await pool.query(
      `INSERT INTO compensacoes (usuario_id, credito_id, deslocamento_id, quantidade, kg_compensado)
       VALUES (?, ?, ?, ?, ?)`, [usuario_id, credito_id, deslocamento_id || null, quantidade, kg]);
    notificar(usuario_id, "Compensação confirmada", `Você compensou ${kg} kg de CO₂.`);
    res.status(201).json({ id: r.insertId, kg_compensado: kg });
  } catch (error) {
    console.error(error);
    res.status(500).json({ erro: "Não foi possível compensar." });
  }
});

// Card 17: compensações realizadas
app.get("/api/compensacoes/:usuarioId", async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT k.id, k.quantidade, k.kg_compensado, k.data_compensacao, p.nome AS projeto
      FROM compensacoes k
      JOIN creditos_carbono c ON c.id = k.credito_id
      JOIN projetos_ambientais p ON p.id = c.projeto_id
      WHERE k.usuario_id = ? ORDER BY k.data_compensacao DESC`, [req.params.usuarioId]);
    res.json(rows);
  } catch (error) { res.status(500).json({ erro: error.message }); }
});

// Card 30: meta mensal de redução (e acompanhamento do mês atual)
app.get("/api/metas/:usuarioId", async (req, res) => {
  try {
    const mes = new Date().toISOString().slice(0, 7);
    const [m] = await pool.query("SELECT meta_kg FROM metas WHERE usuario_id = ? AND mes = ?",
      [req.params.usuarioId, mes]);
    const [e] = await pool.query(
      `SELECT COALESCE(SUM(emissao_kg), 0) AS emitido FROM deslocamentos
       WHERE usuario_id = ? AND DATE_FORMAT(data_deslocamento, '%Y-%m') = ?`,
      [req.params.usuarioId, mes]);
    res.json({ mes, meta_kg: m.length ? Number(m[0].meta_kg) : null, emitido_kg: Number(e[0].emitido) });
  } catch (error) { res.status(500).json({ erro: error.message }); }
});

app.post("/api/metas", async (req, res) => {
  const { usuario_id, meta_kg } = req.body;
  if (!usuario_id || !(Number(meta_kg) > 0)) {
    return res.status(400).json({ erro: "Informe uma meta maior que zero." });
  }
  try {
    const mes = new Date().toISOString().slice(0, 7);
    await pool.query(
      `INSERT INTO metas (usuario_id, mes, meta_kg) VALUES (?, ?, ?)
       ON DUPLICATE KEY UPDATE meta_kg = VALUES(meta_kg)`, [usuario_id, mes, meta_kg]);
    res.json({ ok: true });
  } catch (error) { res.status(500).json({ erro: error.message }); }
});

const PORTA = process.env.PORT || 3000;
pool.query("SELECT 1")
  .then(() => { console.log("MySQL conectado."); return ensureSchema(); })
  .then(() => console.log("Tabelas dos sprints 2 e 3 verificadas."))
  .catch((e) => console.error("ERRO ao conectar no MySQL:", e.code, e.message));

app.listen(PORTA, () => {
  console.log(`CarbonMob API rodando em http://localhost:${PORTA}`);
}).on("error", (e) => {
  if (e.code === "EADDRINUSE") {
    console.error(`A porta ${PORTA} já está em uso. Feche o outro processo ou mude PORT no .env.`);
  } else {
    console.error(e);
  }
  process.exit(1);
});
