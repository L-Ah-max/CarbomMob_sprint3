# CarbonMob

Projeto completo inicial do TCC CarbonMob.

## Tecnologias
- Flutter Web
- Node.js + Express
- MySQL
- JSON
- Firebase Hosting (deploy será feito depois)

## Fluxo
Flutter -> API Node.js -> MySQL

## Executar localmente

### Banco
Abra `database/schema.sql` no MySQL Workbench e execute.

### API
Entre em `backend`:

```bash
npm install
npm run dev
```

API: http://localhost:3000

### Flutter
Entre em `flutter_app`:

```bash
flutter pub get
flutter run -d chrome
```

## Fatores de emissão
Os fatores ficam em `data/emission_factors.json`.

Os valores devem ser preenchidos com a fonte padronizada adotada no TCC. Não foram inventados neste projeto.

## Firebase
O deploy será configurado depois que o sistema estiver funcionando localmente.
