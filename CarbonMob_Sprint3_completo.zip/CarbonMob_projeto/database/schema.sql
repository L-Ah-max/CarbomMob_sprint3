CREATE DATABASE IF NOT EXISTS carbonmob;
USE carbonmob;

CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    tipo VARCHAR(20) NOT NULL DEFAULT 'usuario'
);

CREATE TABLE IF NOT EXISTS deslocamentos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    origem VARCHAR(255) NOT NULL,
    destino VARCHAR(255) NOT NULL,
    distancia_km DECIMAL(10,2) NOT NULL,
    tempo_minutos INT NOT NULL,
    transporte VARCHAR(50) NOT NULL,
    combustivel VARCHAR(50),
    consumo_km_l DECIMAL(10,2),
    combustivel_gasto_l DECIMAL(10,3),
    emissao_kg DECIMAL(10,3) NOT NULL,
    data_deslocamento DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

CREATE TABLE IF NOT EXISTS projetos_ambientais (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(150) NOT NULL,
    empresa VARCHAR(150) NOT NULL,
    tipo VARCHAR(100) NOT NULL,
    descricao TEXT
);

CREATE TABLE IF NOT EXISTS creditos_carbono (
    id INT AUTO_INCREMENT PRIMARY KEY,
    projeto_id INT NOT NULL,
    preco DECIMAL(10,2) NOT NULL,
    compensacao_kg DECIMAL(10,2) NOT NULL,
    quantidade_disponivel INT NOT NULL,
    FOREIGN KEY (projeto_id) REFERENCES projetos_ambientais(id)
);

CREATE TABLE IF NOT EXISTS compras_creditos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    credito_id INT NOT NULL,
    quantidade INT NOT NULL,
    valor_total DECIMAL(10,2) NOT NULL,
    data_compra DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
    FOREIGN KEY (credito_id) REFERENCES creditos_carbono(id)
);

INSERT INTO projetos_ambientais (nome, empresa, tipo, descricao)
SELECT 'Projeto de Reflorestamento', 'Empresa Ambiental Exemplo', 'Reflorestamento', 'Projeto inicial.'
WHERE NOT EXISTS (SELECT 1 FROM projetos_ambientais WHERE nome = 'Projeto de Reflorestamento');

INSERT INTO projetos_ambientais (nome, empresa, tipo, descricao)
SELECT 'Agricultura Regenerativa', 'Projeto Sustentável Exemplo', 'Agricultura regenerativa', 'Projeto inicial.'
WHERE NOT EXISTS (SELECT 1 FROM projetos_ambientais WHERE nome = 'Agricultura Regenerativa');

INSERT INTO creditos_carbono (projeto_id, preco, compensacao_kg, quantidade_disponivel)
SELECT id, 35.00, 100.00, 500 FROM projetos_ambientais
WHERE nome = 'Projeto de Reflorestamento'
AND NOT EXISTS (SELECT 1 FROM creditos_carbono c WHERE c.projeto_id = projetos_ambientais.id);

INSERT INTO creditos_carbono (projeto_id, preco, compensacao_kg, quantidade_disponivel)
SELECT id, 42.00, 100.00, 300 FROM projetos_ambientais
WHERE nome = 'Agricultura Regenerativa'
AND NOT EXISTS (SELECT 1 FROM creditos_carbono c WHERE c.projeto_id = projetos_ambientais.id);
