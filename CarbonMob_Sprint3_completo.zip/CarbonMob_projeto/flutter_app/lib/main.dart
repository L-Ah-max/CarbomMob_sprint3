import 'package:flutter/material.dart';
import 'screens/login_screen.dart';

void main() {
  runApp(const CarbonMobApp());
}

class CarbonMobApp extends StatelessWidget {
  const CarbonMobApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'CarbonMob',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF236B3A),
        ),
        useMaterial3: true,
      ),
      home: const LoginScreen(),
    );
  }
}
