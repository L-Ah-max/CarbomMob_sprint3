import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  static const String baseUrl = 'http://localhost:3000/api';

  static Future<Map<String, dynamic>> calcularEmissao({
    required double distancia,
    required String transporte,
    String? combustivel,
    double? consumo,
  }) async {
    final response = await http.post(
      Uri.parse('$baseUrl/emissoes/calcular'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'distancia': distancia,
        'transporte': transporte,
        'combustivel': combustivel,
        'consumo': consumo,
      }),
    );

    final body = jsonDecode(response.body);

    if (response.statusCode != 200) {
      throw Exception(body['erro']);
    }

    return body;
  }

  static Future<void> cadastrarUsuario(
    String nome,
    String email,
    String senha,
  ) async {
    final response = await http.post(
      Uri.parse('$baseUrl/usuarios'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'nome': nome,
        'email': email,
        'senha': senha,
      }),
    );

    if (response.statusCode != 201) {
      final body = jsonDecode(response.body);
      throw Exception(body['erro']);
    }
  }

  static Future<Map<String, dynamic>> entrar(String email, String senha) async {
    final response = await http.post(
      Uri.parse('$baseUrl/login'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'email': email.trim(), 'senha': senha}),
    );
    final body = jsonDecode(response.body);
    if (response.statusCode != 200) {
      throw Exception(body['erro'] ?? 'Não foi possível entrar.');
    }
    return Map<String, dynamic>.from(body);
  }

  static Future<void> salvarDeslocamento(Map<String, dynamic> dados) async {
    final response = await http.post(
      Uri.parse('$baseUrl/deslocamentos'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(dados),
    );

    if (response.statusCode != 201) {
      final body = jsonDecode(response.body);
      throw Exception(body['erro']);
    }
  }

  static Future<List<dynamic>> buscarHistorico(int usuarioId) async {
    final response = await http.get(
      Uri.parse('$baseUrl/deslocamentos/$usuarioId'),
    );

    if (response.statusCode != 200) {
      throw Exception('Erro ao buscar histórico.');
    }

    return jsonDecode(response.body);
  }

  static Future<Map<String, dynamic>> buscarImpacto(int usuarioId) async {
    final response = await http.get(
      Uri.parse('$baseUrl/impacto/$usuarioId'),
    );

    if (response.statusCode != 200) {
      throw Exception('Erro ao buscar impacto.');
    }

    return jsonDecode(response.body);
  }

  static Future<List<dynamic>> buscarCreditos() async {
    final response = await http.get(
      Uri.parse('$baseUrl/creditos'),
    );

    if (response.statusCode != 200) {
      throw Exception('Erro ao buscar créditos.');
    }

    return jsonDecode(response.body);
  }

  static Future<void> atualizarDeslocamento(
      int id, Map<String, dynamic> dados) async {
    final response = await http.put(
      Uri.parse('$baseUrl/deslocamentos/$id'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(dados),
    );
    if (response.statusCode != 200) {
      final body = jsonDecode(response.body);
      throw Exception(body['erro'] ?? 'Não foi possível atualizar.');
    }
  }

  static Future<void> excluirDeslocamento(int id, int usuarioId) async {
    final response = await http.delete(
      Uri.parse('$baseUrl/deslocamentos/$id?usuario_id=$usuarioId'),
    );
    if (response.statusCode != 200) {
      final body = jsonDecode(response.body);
      throw Exception(body['erro'] ?? 'Não foi possível excluir.');
    }
  }

  // ---- chamadas genéricas usadas pelos sprints 2 e 3 ----
  static Future<dynamic> _chamar(String metodo, String caminho,
      [Map<String, dynamic>? corpo]) async {
    final uri = Uri.parse('$baseUrl$caminho');
    final cab = {'Content-Type': 'application/json'};
    late http.Response r;
    if (metodo == 'GET') {
      r = await http.get(uri);
    } else if (metodo == 'POST') {
      r = await http.post(uri, headers: cab, body: jsonEncode(corpo));
    } else {
      r = await http.put(uri, headers: cab, body: jsonEncode(corpo));
    }
    final dados = r.body.isEmpty ? null : jsonDecode(r.body);
    if (r.statusCode >= 400) {
      throw Exception(dados is Map ? (dados['erro'] ?? 'Erro') : 'Erro');
    }
    return dados;
  }

  static Future<dynamic> get(String caminho) => _chamar('GET', caminho);
  static Future<dynamic> post(String caminho, Map<String, dynamic> corpo) =>
      _chamar('POST', caminho, corpo);
  static Future<dynamic> put(String caminho, Map<String, dynamic> corpo) =>
      _chamar('PUT', caminho, corpo);
}
