import 'package:flutter/material.dart';

/// Converte valores que o MySQL pode devolver como texto ("12.50") ou número.
double num_(dynamic v) => double.tryParse('$v') ?? 0;
int int_(dynamic v) => num_(v).round();

String reais(dynamic v) => 'R\$ ${num_(v).toStringAsFixed(2).replaceAll('.', ',')}';
String kg(dynamic v) => '${num_(v).toStringAsFixed(2).replaceAll('.', ',')} kg';

String dataBr(dynamic v) {
  final t = '$v';
  if (t.length < 10) return t;
  return '${t.substring(8, 10)}/${t.substring(5, 7)}/${t.substring(0, 4)}';
}

void aviso(BuildContext context, String texto) {
  if (!context.mounted) return;
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(texto)));
}

String limpaErro(Object e) => e.toString().replaceFirst('Exception: ', '');
