/// Guarda o usuário logado enquanto o app está aberto.
class Sessao {
  static int? usuarioId;
  static String? nome;

  static void entrar(Map<String, dynamic> usuario) {
    usuarioId = (usuario['id'] as num).toInt();
    nome = usuario['nome']?.toString();
  }

  static void sair() {
    usuarioId = null;
    nome = null;
  }
}
