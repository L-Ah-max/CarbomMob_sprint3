import 'package:flutter/material.dart';
import '../services/api_service.dart';
import 'register_screen.dart';
import 'home_screen.dart';
import '../services/sessao.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final email = TextEditingController();
  final senha = TextEditingController();
  bool carregando = false;

  @override
  void dispose() {
    email.dispose();
    senha.dispose();
    super.dispose();
  }

  Future<void> entrar() async {
    if (email.text.trim().isEmpty || senha.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Preencha e-mail e senha.')),
      );
      return;
    }
    setState(() => carregando = true);
    try {
      final usuario = await ApiService.entrar(email.text, senha.text);
      Sessao.entrar(usuario);
      if (!mounted) return;
      Navigator.pushReplacement(context,
        MaterialPageRoute(builder: (_) => const HomeScreen()));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))),
      );
    } finally {
      if (mounted) setState(() => carregando = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 430),
          child: Card(child: Padding(
            padding: const EdgeInsets.all(25),
            child: Column(children: [
              const Icon(Icons.eco, size: 70, color: Colors.green),
              const SizedBox(height: 10),
              const Text('CarbonMob', style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              const Text('Mobilidade sustentável'),
              const SizedBox(height: 30),
              TextField(controller: email, keyboardType: TextInputType.emailAddress,
                decoration: const InputDecoration(labelText: 'E-mail', border: OutlineInputBorder())),
              const SizedBox(height: 15),
              TextField(controller: senha, obscureText: true, onSubmitted: (_) => carregando ? null : entrar(),
                decoration: const InputDecoration(labelText: 'Senha', border: OutlineInputBorder())),
              const SizedBox(height: 20),
              SizedBox(width: double.infinity, child: FilledButton(
                onPressed: carregando ? null : entrar,
                child: Text(carregando ? 'Entrando...' : 'Entrar'),
              )),
              TextButton(onPressed: carregando ? null : () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const RegisterScreen())),
                child: const Text('Criar conta')),
            ]),
          )),
        ),
      )),
    );
  }
}
