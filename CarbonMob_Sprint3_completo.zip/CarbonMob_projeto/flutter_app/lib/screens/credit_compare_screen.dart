import 'package:flutter/material.dart';
import '../services/util.dart';

/// Cards 08/14: comparação lado a lado de créditos de carbono.
class CreditCompareScreen extends StatelessWidget {
  final List<dynamic> creditos;
  const CreditCompareScreen({super.key, required this.creditos});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Comparar créditos')),
      body: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: DataTable(
            columns: const [
              DataColumn(label: Text('Crédito')),
              DataColumn(label: Text('Empresa')),
              DataColumn(label: Text('Tipo')),
              DataColumn(label: Text('Preço')),
              DataColumn(label: Text('CO₂ por crédito')),
              DataColumn(label: Text('Preço por kg')),
              DataColumn(label: Text('Disponível')),
            ],
            rows: creditos.map((c) {
              final porKg = num_(c['compensacao_kg']) == 0
                  ? 0
                  : num_(c['preco']) / num_(c['compensacao_kg']);
              return DataRow(cells: [
                DataCell(Text('${c['projeto']}')),
                DataCell(Text('${c['empresa']}')),
                DataCell(Text('${c['tipo']}')),
                DataCell(Text(reais(c['preco']))),
                DataCell(Text(kg(c['compensacao_kg']))),
                DataCell(Text(reais(porKg))),
                DataCell(Text('${c['quantidade_disponivel']}')),
              ]);
            }).toList(),
          ),
        ),
      ),
    );
  }
}
