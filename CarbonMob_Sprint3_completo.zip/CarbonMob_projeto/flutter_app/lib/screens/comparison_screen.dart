import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../services/util.dart';

/// Card 07: comparar meios de transporte para o mesmo trajeto.
class ComparisonScreen extends StatefulWidget {
  final double? distancia;
  const ComparisonScreen({super.key, this.distancia});

  @override
  State<ComparisonScreen> createState() => _ComparisonScreenState();
}

class _ComparisonScreenState extends State<ComparisonScreen> {
  late final TextEditingController distancia = TextEditingController(
      text: widget.distancia == null ? '' : '${widget.distancia}');
  final consumo = TextEditingController(text: '10');
  String combustivel = 'gasolina';
  List<dynamic> resultados = [];
  bool carregando = false;

  Future<void> comparar() async {
    final d = double.tryParse(distancia.text.replaceAll(',', '.'));
    if (d == null || d <= 0) {
      aviso(context, 'Informe uma distância válida.');
      return;
    }
    setState(() => carregando = true);
    try {
      final r = await ApiService.post('/comparar-transportes', {
        'distancia': d,
        'combustivel': combustivel,
        'consumo': double.tryParse(consumo.text.replaceAll(',', '.')),
      });
      setState(() => resultados = r as List);
    } catch (e) {
      if (!mounted) return;
      aviso(context, limpaErro(e));
    } finally {
      if (mounted) setState(() => carregando = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Comparar transportes')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: distancia,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(
                labelText: 'Distância do trajeto (km)',
                border: OutlineInputBorder()),
          ),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(
              child: DropdownButtonFormField<String>(
                value: combustivel,
                decoration: const InputDecoration(
                    labelText: 'Combustível (carro/moto)',
                    border: OutlineInputBorder()),
                items: const [
                  DropdownMenuItem(value: 'gasolina', child: Text('Gasolina')),
                  DropdownMenuItem(value: 'etanol', child: Text('Etanol')),
                  DropdownMenuItem(value: 'diesel', child: Text('Diesel')),
                ],
                onChanged: (v) => setState(() => combustivel = v!),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: TextField(
                controller: consumo,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                    labelText: 'Consumo (km/l)', border: OutlineInputBorder()),
              ),
            ),
          ]),
          const SizedBox(height: 12),
          FilledButton(
            onPressed: carregando ? null : comparar,
            child: Text(carregando ? 'Calculando...' : 'Comparar'),
          ),
          const SizedBox(height: 15),
          ...resultados.map((r) => Card(
                child: ListTile(
                  title: Text('${r['nome']}'),
                  subtitle: Text(
                    'Tempo estimado: ${r['tempo_min']} min\n'
                    '${r['emissao_kg'] == null ? 'Emissão: não disponível' : 'Emissão: ${kg(r['emissao_kg'])} de CO₂'}',
                  ),
                  isThreeLine: true,
                ),
              )),
          const Padding(
            padding: EdgeInsets.only(top: 10),
            child: Text(
              'Tempos calculados com velocidades médias de referência. '
              'O CarbonMob apresenta informações para auxiliar sua decisão; '
              'não escolhe o transporte pelo usuário.',
              style: TextStyle(color: Colors.grey),
            ),
          ),
        ],
      ),
    );
  }
}
