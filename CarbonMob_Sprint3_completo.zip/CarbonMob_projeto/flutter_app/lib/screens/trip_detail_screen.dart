import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../services/sessao.dart';
import '../services/util.dart';

/// Card 12: detalhes de um deslocamento registrado.
class TripDetailScreen extends StatelessWidget {
  final int id;
  const TripDetailScreen({super.key, required this.id});

  Widget linha(String rotulo, String valor) => ListTile(
        dense: true,
        title: Text(rotulo, style: const TextStyle(color: Colors.grey)),
        subtitle: Text(valor, style: const TextStyle(fontSize: 17)),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Detalhes do deslocamento')),
      body: FutureBuilder<dynamic>(
        future: ApiService.get('/deslocamento/$id?usuario_id=${Sessao.usuarioId}'),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text(limpaErro(snapshot.error!)));
          }
          final d = snapshot.data as Map;
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              linha('Origem', '${d['origem']}'),
              linha('Destino', '${d['destino']}'),
              linha('Data', dataBr(d['data_deslocamento'])),
              linha('Distância', '${d['distancia_km']} km'),
              linha('Tempo', '${d['tempo_minutos']} min'),
              linha('Transporte', '${d['transporte']}'),
              if (d['combustivel'] != null)
                linha('Combustível', '${d['combustivel']}'),
              if (d['consumo_km_l'] != null)
                linha('Consumo', '${d['consumo_km_l']} km/l'),
              if (d['combustivel_gasto_l'] != null)
                linha('Combustível gasto', '${d['combustivel_gasto_l']} L'),
              linha('Emissão estimada de CO₂', kg(d['emissao_kg'])),
            ],
          );
        },
      ),
    );
  }
}
