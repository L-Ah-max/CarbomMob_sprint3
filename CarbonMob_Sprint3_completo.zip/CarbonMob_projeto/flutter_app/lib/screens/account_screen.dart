import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../services/sessao.dart';
import '../services/util.dart';

/// Cards 41 (alterar senha) e 44 (notificações).
class AccountScreen extends StatelessWidget {
  const AccountScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: Text('Conta${Sessao.nome == null ? '' : ' • ${Sessao.nome}'}'),
          bottom: const TabBar(tabs: [
            Tab(text: 'Alterar senha'),
            Tab(text: 'Notificações'),
          ]),
        ),
        body: const TabBarView(children: [_SenhaTab(), _NotificacoesTab()]),
      ),
    );
  }
}

class _SenhaTab extends StatefulWidget {
  const _SenhaTab();
  @override
  State<_SenhaTab> createState() => _SenhaTabState();
}

class _SenhaTabState extends State<_SenhaTab> {
  final atual = TextEditingController();
  final nova = TextEditingController();
  final confirmar = TextEditingController();

  Future<void> salvar() async {
    if (nova.text != confirmar.text) {
      aviso(context, 'A confirmação não confere com a nova senha.');
      return;
    }
    try {
      await ApiService.put('/usuarios/${Sessao.usuarioId}/senha', {
        'senha_atual': atual.text,
        'nova_senha': nova.text,
      });
      if (!mounted) return;
      aviso(context, 'Senha alterada com sucesso.');
      atual.clear();
      nova.clear();
      confirmar.clear();
    } catch (e) {
      if (!mounted) return;
      aviso(context, limpaErro(e));
    }
  }

  Widget campo(TextEditingController c, String r) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: TextField(
          controller: c,
          obscureText: true,
          decoration:
              InputDecoration(labelText: r, border: const OutlineInputBorder()),
        ),
      );

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(16), children: [
      campo(atual, 'Senha atual'),
      campo(nova, 'Nova senha (mínimo 8 caracteres)'),
      campo(confirmar, 'Confirmar nova senha'),
      FilledButton(onPressed: salvar, child: const Text('Alterar senha')),
    ]);
  }
}

class _NotificacoesTab extends StatelessWidget {
  const _NotificacoesTab();

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<dynamic>(
      future: ApiService.get('/notificacoes/${Sessao.usuarioId}'),
      builder: (context, s) {
        if (s.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        if (s.hasError) return Center(child: Text(limpaErro(s.error!)));
        final lista = (s.data as List?) ?? [];
        if (lista.isEmpty) {
          return const Center(child: Text('Nenhuma notificação.'));
        }
        return ListView(
          padding: const EdgeInsets.all(12),
          children: lista.map((i) {
            final n = i as Map;
            return Card(
              child: ListTile(
                leading: Icon(n['enviado_email'] == 1
                    ? Icons.mark_email_read
                    : Icons.notifications),
                title: Text('${n['assunto']}'),
                subtitle: Text('${n['mensagem']}\n${dataBr(n['data_criacao'])}'),
                isThreeLine: true,
              ),
            );
          }).toList(),
        );
      },
    );
  }
}
