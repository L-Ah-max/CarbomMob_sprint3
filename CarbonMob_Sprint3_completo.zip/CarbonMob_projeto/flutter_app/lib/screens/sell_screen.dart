import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../services/sessao.dart';
import '../services/util.dart';

/// Cards 21 e 48: disponibilizar créditos para venda e acompanhá-los.
class SellScreen extends StatelessWidget {
  const SellScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Vender créditos'),
          bottom: const TabBar(tabs: [
            Tab(text: 'Meus créditos à venda'),
            Tab(text: 'Disponibilizar'),
          ]),
        ),
        body: const TabBarView(children: [_MinhaLista(), _Formulario()]),
      ),
    );
  }
}

class _MinhaLista extends StatelessWidget {
  const _MinhaLista();

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<dynamic>(
      future: ApiService.get('/creditos/vendedor/${Sessao.usuarioId}'),
      builder: (context, s) {
        if (s.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        if (s.hasError) return Center(child: Text(limpaErro(s.error!)));
        final lista = (s.data as List?) ?? [];
        if (lista.isEmpty) {
          return const Center(
              child: Text('Você ainda não disponibilizou créditos.'));
        }
        return ListView(
          padding: const EdgeInsets.all(12),
          children: lista.map((i) {
            final c = i as Map;
            final esgotado = int_(c['quantidade_disponivel']) == 0;
            return Card(
              child: ListTile(
                title: Text('${c['projeto']} (${c['tipo']})'),
                subtitle: Text(
                    '${reais(c['preco'])} • ${kg(c['compensacao_kg'])} por crédito\n'
                    'À venda: ${c['quantidade_disponivel']} • Vendidos: ${int_(c['vendidos'])}'),
                isThreeLine: true,
                trailing: Chip(label: Text(esgotado ? 'Esgotado' : 'Disponível')),
              ),
            );
          }).toList(),
        );
      },
    );
  }
}

class _Formulario extends StatefulWidget {
  const _Formulario();
  @override
  State<_Formulario> createState() => _FormularioState();
}

class _FormularioState extends State<_Formulario> {
  final projeto = TextEditingController();
  final empresa = TextEditingController();
  final tipo = TextEditingController();
  final descricao = TextEditingController();
  final preco = TextEditingController();
  final compensacao = TextEditingController();
  final quantidade = TextEditingController();

  Widget campo(TextEditingController c, String rotulo, {bool numero = false}) =>
      Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: TextField(
          controller: c,
          keyboardType: numero ? TextInputType.number : TextInputType.text,
          decoration: InputDecoration(
              labelText: rotulo, border: const OutlineInputBorder()),
        ),
      );

  Future<void> enviar() async {
    try {
      await ApiService.post('/creditos', {
        'usuario_id': Sessao.usuarioId,
        'projeto': projeto.text,
        'empresa': empresa.text,
        'tipo': tipo.text,
        'descricao': descricao.text,
        'preco': double.tryParse(preco.text.replaceAll(',', '.')),
        'compensacao_kg': double.tryParse(compensacao.text.replaceAll(',', '.')),
        'quantidade': int.tryParse(quantidade.text),
      });
      if (!mounted) return;
      aviso(context, 'Crédito disponibilizado na loja.');
      for (final c in [projeto, empresa, tipo, descricao, preco, compensacao, quantidade]) {
        c.clear();
      }
    } catch (e) {
      if (!mounted) return;
      aviso(context, limpaErro(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        campo(projeto, 'Nome do projeto'),
        campo(empresa, 'Empresa'),
        campo(tipo, 'Tipo (ex.: Reflorestamento)'),
        campo(descricao, 'Descrição'),
        campo(preco, 'Preço por crédito (R\$)', numero: true),
        campo(compensacao, 'CO₂ compensado por crédito (kg)', numero: true),
        campo(quantidade, 'Quantidade de créditos', numero: true),
        FilledButton(onPressed: enviar, child: const Text('Disponibilizar')),
      ],
    );
  }
}
