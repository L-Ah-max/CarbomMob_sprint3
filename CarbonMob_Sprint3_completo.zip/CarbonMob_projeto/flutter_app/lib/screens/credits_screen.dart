import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../services/sessao.dart';
import '../services/util.dart';
import 'credit_compare_screen.dart';

/// Loja de créditos: consulta (08), comparação (14), simulação (10) e compra (09).
class CreditsScreen extends StatefulWidget {
  const CreditsScreen({super.key});

  @override
  State<CreditsScreen> createState() => _CreditsScreenState();
}

class _CreditsScreenState extends State<CreditsScreen> {
  String busca = '';
  bool maisBarato = true;
  final selecionados = <int>{};
  late Future<dynamic> futuro = ApiService.get('/creditos');

  void recarregar() => setState(() => futuro = ApiService.get('/creditos'));

  Future<void> detalhes(Map item) async {
    await showDialog<void>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('${item['projeto']}'),
        content: Text(
          'Empresa: ${item['empresa']}\n'
          'Tipo: ${item['tipo']}\n'
          '${item['descricao'] ?? ''}\n\n'
          'Cada crédito compensa ${kg(item['compensacao_kg'])} de CO₂\n'
          'Preço: ${reais(item['preco'])}\n'
          'Disponível: ${item['quantidade_disponivel']}',
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Fechar')),
        ],
      ),
    );
  }

  Future<void> comprar(Map item) async {
    final qtd = TextEditingController(text: '1');
    final emissao = TextEditingController();
    String simulacao = '';

    final confirmar = await showDialog<bool>(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (context, setLocal) {
          final q = int.tryParse(qtd.text) ?? 0;
          return AlertDialog(
            title: Text('Comprar: ${item['projeto']}'),
            content: SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                TextField(
                  controller: qtd,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                      labelText: 'Quantidade de créditos'),
                  onChanged: (_) => setLocal(() {}),
                ),
                const SizedBox(height: 8),
                Text('Total: ${reais(q * num_(item['preco']))}',
                    style: const TextStyle(fontWeight: FontWeight.bold)),
                const Divider(height: 24),
                const Text('Simulador: quantos créditos preciso?'),
                TextField(
                  controller: emissao,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                      labelText: 'Emissão a compensar (kg de CO₂)'),
                ),
                TextButton(
                  onPressed: () async {
                    try {
                      final r = await ApiService.get(
                          '/simular?emissao_kg=${emissao.text.replaceAll(',', '.')}&credito_id=${item['id']}');
                      setLocal(() => simulacao =
                          'Você precisa de ${r['unidades']} crédito(s): ${reais(r['valor_total'])}');
                    } catch (e) {
                      setLocal(() => simulacao = limpaErro(e));
                    }
                  },
                  child: const Text('Simular'),
                ),
                if (simulacao.isNotEmpty) Text(simulacao),
                const SizedBox(height: 8),
                const Text('Pagamento simulado (sem cobrança real).',
                    style: TextStyle(color: Colors.grey, fontSize: 12)),
              ]),
            ),
            actions: [
              TextButton(
                  onPressed: () => Navigator.pop(context, false),
                  child: const Text('Cancelar')),
              FilledButton(
                  onPressed: q > 0 ? () => Navigator.pop(context, true) : null,
                  child: const Text('Confirmar compra')),
            ],
          );
        },
      ),
    );
    if (confirmar != true) return;
    try {
      final r = await ApiService.post('/compras', {
        'usuario_id': Sessao.usuarioId,
        'credito_id': item['id'],
        'quantidade': int.parse(qtd.text),
      });
      if (!mounted) return;
      aviso(context,
          'Compra #${r['id']} realizada: ${reais(r['valor_total'])}. Veja o comprovante em "Meus créditos".');
      recarregar();
    } catch (e) {
      if (!mounted) return;
      aviso(context, limpaErro(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Créditos de carbono'),
        actions: [
          TextButton.icon(
            onPressed: selecionados.length < 2
                ? null
                : () async {
                    final lista = (await futuro as List)
                        .where((c) => selecionados.contains(c['id']))
                        .toList();
                    if (!context.mounted) return;
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => CreditCompareScreen(creditos: lista)),
                    );
                  },
            icon: const Icon(Icons.compare_arrows),
            label: Text('Comparar (${selecionados.length})'),
          ),
        ],
      ),
      body: FutureBuilder<dynamic>(
        future: futuro,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text(limpaErro(snapshot.error!)));
          }
          var lista = ((snapshot.data as List?) ?? []).where((item) {
            final texto =
                '${item['projeto']} ${item['empresa']} ${item['tipo']}'
                    .toLowerCase();
            return texto.contains(busca.toLowerCase());
          }).toList();
          lista.sort((a, b) => maisBarato
              ? num_(a['preco']).compareTo(num_(b['preco']))
              : num_(b['preco']).compareTo(num_(a['preco'])));

          return Column(children: [
            Padding(
              padding: const EdgeInsets.all(15),
              child: Row(children: [
                Expanded(
                  child: TextField(
                    decoration: const InputDecoration(
                      labelText: 'Pesquisar crédito',
                      prefixIcon: Icon(Icons.search),
                      border: OutlineInputBorder(),
                    ),
                    onChanged: (v) => setState(() => busca = v),
                  ),
                ),
                const SizedBox(width: 10),
                TextButton(
                  onPressed: () => setState(() => maisBarato = !maisBarato),
                  child: Text(maisBarato ? 'Menor preço' : 'Maior preço'),
                ),
              ]),
            ),
            Expanded(
              child: lista.isEmpty
                  ? const Center(child: Text('Nenhum crédito encontrado.'))
                  : ListView.builder(
                      itemCount: lista.length,
                      itemBuilder: (context, index) {
                        final item = lista[index] as Map;
                        final id = item['id'] as int;
                        return Card(
                          margin: const EdgeInsets.symmetric(
                              horizontal: 15, vertical: 7),
                          child: ListTile(
                            leading: Checkbox(
                              value: selecionados.contains(id),
                              onChanged: (v) => setState(() => v == true
                                  ? selecionados.add(id)
                                  : selecionados.remove(id)),
                            ),
                            onTap: () => detalhes(item),
                            title: Text('${item['projeto']}'),
                            subtitle: Text(
                              '${item['tipo']}\n'
                              '${kg(item['compensacao_kg'])} de CO₂ por crédito • '
                              '${reais(item['preco'])}\n'
                              'Disponível: ${item['quantidade_disponivel']}',
                            ),
                            isThreeLine: true,
                            trailing: FilledButton(
                              onPressed: () => comprar(item),
                              child: const Text('Comprar'),
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ]);
        },
      ),
    );
  }
}
