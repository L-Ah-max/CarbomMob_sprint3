import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../services/sessao.dart';
import 'comparison_screen.dart';

class NewTripScreen extends StatefulWidget {
  const NewTripScreen({super.key});

  @override
  State<NewTripScreen> createState() => _NewTripScreenState();
}

class _NewTripScreenState extends State<NewTripScreen> {
  final origem = TextEditingController();
  final destino = TextEditingController();
  final distancia = TextEditingController();
  final tempo = TextEditingController();
  final consumo = TextEditingController();

  String transporte = 'carro';
  String combustivel = 'gasolina';

  double? emissao;
  double? combustivelGasto;

  bool get precisaVeiculoAgora => transporte == 'carro' || transporte == 'moto';

  Future<void> calcular() async {
    try {
      final resultado = await ApiService.calcularEmissao(
        distancia: double.parse(distancia.text),
        transporte: transporte,
        combustivel: precisaVeiculoAgora ? combustivel : null,
        consumo: precisaVeiculoAgora ? double.tryParse(consumo.text) : null,
      );

      setState(() {
        emissao = (resultado['emissao_kg'] as num).toDouble();
        combustivelGasto =
            (resultado['combustivel_gasto'] as num).toDouble();
      });
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))),
      );
    }
  }

  Future<void> salvar() async {
    if (emissao == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Calcule a emissão primeiro.')),
      );
      return;
    }

    try {
      await ApiService.salvarDeslocamento({
        'usuario_id': Sessao.usuarioId,
        'origem': origem.text,
        'destino': destino.text,
        'distancia': double.parse(distancia.text),
        'tempo_minutos': int.parse(tempo.text),
        'transporte': transporte,
        'combustivel': precisaVeiculoAgora ? combustivel : null,
        'consumo': precisaVeiculoAgora ? double.tryParse(consumo.text) : null,
      });

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Deslocamento salvo.')),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('$e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final precisaVeiculo =
        transporte == 'carro' || transporte == 'moto';

    return Scaffold(
      appBar: AppBar(title: const Text('Novo deslocamento')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 650),
            child: Column(
              children: [
                TextField(
                  controller: origem,
                  decoration: const InputDecoration(
                    labelText: 'Origem',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 15),
                TextField(
                  controller: destino,
                  decoration: const InputDecoration(
                    labelText: 'Destino',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 15),
                TextField(
                  controller: distancia,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'Distância em km',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 15),
                TextField(
                  controller: tempo,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'Tempo em minutos',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 15),
                DropdownButtonFormField<String>(
                  value: transporte,
                  decoration: const InputDecoration(
                    labelText: 'Meio de transporte',
                    border: OutlineInputBorder(),
                  ),
                  items: const [
                    DropdownMenuItem(
                      value: 'a_pe',
                      child: Text('A pé'),
                    ),
                    DropdownMenuItem(
                      value: 'bicicleta',
                      child: Text('Bicicleta'),
                    ),
                    DropdownMenuItem(
                      value: 'transporte_publico',
                      child: Text('Transporte público'),
                    ),
                    DropdownMenuItem(
                      value: 'carro',
                      child: Text('Carro'),
                    ),
                    DropdownMenuItem(
                      value: 'moto',
                      child: Text('Moto'),
                    ),
                    DropdownMenuItem(
                      value: 'carro_eletrico',
                      child: Text('Carro elétrico'),
                    ),
                  ],
                  onChanged: (value) {
                    if (value != null) {
                      setState(() => transporte = value);
                    }
                  },
                ),
                if (precisaVeiculo) ...[
                  const SizedBox(height: 15),
                  DropdownButtonFormField<String>(
                    value: combustivel,
                    decoration: const InputDecoration(
                      labelText: 'Combustível',
                      border: OutlineInputBorder(),
                    ),
                    items: const [
                      DropdownMenuItem(
                        value: 'gasolina',
                        child: Text('Gasolina'),
                      ),
                      DropdownMenuItem(
                        value: 'etanol',
                        child: Text('Etanol'),
                      ),
                      DropdownMenuItem(
                        value: 'diesel',
                        child: Text('Diesel'),
                      ),
                    ],
                    onChanged: (value) {
                      if (value != null) {
                        setState(() => combustivel = value);
                      }
                    },
                  ),
                  const SizedBox(height: 15),
                  TextField(
                    controller: consumo,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      labelText: 'Consumo do veículo (km/L)',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ],
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: calcular,
                    child: const Text('Calcular emissão'),
                  ),
                ),
                if (emissao != null) ...[
                  const SizedBox(height: 20),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(18),
                      child: Column(
                        children: [
                          const Text(
                            'Resultado',
                            style: TextStyle(
                              fontSize: 21,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 10),
                          Text(
                            '${emissao!.toStringAsFixed(3)} kg de CO₂',
                            style: const TextStyle(fontSize: 25),
                          ),
                          if (combustivelGasto != null)
                            Text(
                              '${combustivelGasto!.toStringAsFixed(3)} L de combustível',
                            ),
                          const SizedBox(height: 15),
                          FilledButton.tonal(
                            onPressed: salvar,
                            child: const Text('Salvar deslocamento'),
                          ),
                          TextButton(
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => ComparisonScreen(
                                    distancia:
                                        double.parse(distancia.text),
                                  ),
                                ),
                              );
                            },
                            child: const Text(
                              'Comparar outros transportes',
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}
