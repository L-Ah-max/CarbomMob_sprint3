import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../services/sessao.dart';
import '../services/util.dart';
import 'trip_detail_screen.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  late Future<dynamic> futuro;
  String? transporte;
  DateTime? de;
  DateTime? ate;

  final transportes = const {
    'a_pe': 'A pé',
    'bicicleta': 'Bicicleta',
    'carro': 'Carro',
    'moto': 'Moto',
    'transporte_publico': 'Transporte público',
    'carro_eletrico': 'Carro elétrico',
  };

  @override
  void initState() {
    super.initState();
    futuro = buscar();
  }

  String dia(DateTime d) =>
      '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  Future<dynamic> buscar() {
    final q = <String>[];
    if (transporte != null) q.add('transporte=$transporte');
    if (de != null) q.add('de=${dia(de!)}');
    if (ate != null) q.add('ate=${dia(ate!)}');
    final filtro = q.isEmpty ? '' : '?${q.join('&')}';
    return ApiService.get('/deslocamentos/${Sessao.usuarioId}$filtro');
  }

  void recarregar() {
    setState(() {
      futuro = buscar();
    });
  }

  Future<void> escolherData(bool inicio) async {
    final d = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
    );
    if (d == null) return;
    if (inicio) {
      de = d;
    } else {
      ate = d;
    }
    recarregar();
  }

  Future<void> excluir(Map item) async {
    final confirmar = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Excluir deslocamento?'),
        content: Text('${item['origem']} → ${item['destino']}'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancelar')),
          FilledButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Excluir')),
        ],
      ),
    );
    if (confirmar != true) return;
    try {
      await ApiService.excluirDeslocamento(item['id'], Sessao.usuarioId!);
      if (!mounted) return;
      aviso(context, 'Deslocamento excluído.');
      recarregar();
    } catch (e) {
      if (!mounted) return;
      aviso(context, limpaErro(e));
    }
  }

  Future<void> editar(Map item) async {
    final origem = TextEditingController(text: '${item['origem']}');
    final destino = TextEditingController(text: '${item['destino']}');
    final distancia = TextEditingController(text: '${item['distancia_km']}');
    final tempo = TextEditingController(text: '${item['tempo_minutos']}');

    final salvar = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Editar deslocamento'),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(
                controller: origem,
                decoration: const InputDecoration(labelText: 'Origem')),
            TextField(
                controller: destino,
                decoration: const InputDecoration(labelText: 'Destino')),
            TextField(
                controller: distancia,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Distância (km)')),
            TextField(
                controller: tempo,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Tempo (min)')),
          ]),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancelar')),
          FilledButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Salvar')),
        ],
      ),
    );
    if (salvar != true) return;

    try {
      await ApiService.atualizarDeslocamento(item['id'], {
        'usuario_id': Sessao.usuarioId,
        'origem': origem.text,
        'destino': destino.text,
        'distancia': double.parse(distancia.text.replaceAll(',', '.')),
        'tempo_minutos': int.parse(tempo.text),
      });
      if (!mounted) return;
      aviso(context, 'Deslocamento atualizado e emissão recalculada.');
      recarregar();
    } catch (e) {
      if (!mounted) return;
      aviso(context, limpaErro(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Histórico')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Wrap(
              spacing: 10,
              runSpacing: 8,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                DropdownButton<String?>(
                  value: transporte,
                  hint: const Text('Transporte'),
                  items: [
                    const DropdownMenuItem<String?>(
                        value: null, child: Text('Todos')),
                    ...transportes.entries.map((e) =>
                        DropdownMenuItem<String?>(
                            value: e.key, child: Text(e.value))),
                  ],
                  onChanged: (v) {
                    transporte = v;
                    recarregar();
                  },
                ),
                OutlinedButton(
                  onPressed: () => escolherData(true),
                  child: Text(de == null ? 'Data inicial' : 'De ${dia(de!)}'),
                ),
                OutlinedButton(
                  onPressed: () => escolherData(false),
                  child: Text(ate == null ? 'Data final' : 'Até ${dia(ate!)}'),
                ),
                TextButton(
                  onPressed: () {
                    transporte = null;
                    de = null;
                    ate = null;
                    recarregar();
                  },
                  child: const Text('Limpar filtros'),
                ),
              ],
            ),
          ),
          Expanded(
            child: FutureBuilder<dynamic>(
              future: futuro,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (snapshot.hasError) {
                  return Center(child: Text(limpaErro(snapshot.error!)));
                }
                final lista = (snapshot.data as List?) ?? [];
                if (lista.isEmpty) {
                  return const Center(
                      child: Text('Nenhum deslocamento encontrado.'));
                }
                return ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 15),
                  itemCount: lista.length,
                  itemBuilder: (context, index) {
                    final item = lista[index] as Map;
                    return Card(
                      child: ListTile(
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) =>
                                  TripDetailScreen(id: item['id'] as int)),
                        ),
                        title: Text('${item['origem']} → ${item['destino']}'),
                        subtitle: Text(
                          '${dataBr(item['data_deslocamento'])} • '
                          '${item['distancia_km']} km • ${item['tempo_minutos']} min\n'
                          '${transportes[item['transporte']] ?? item['transporte']} • '
                          '${kg(item['emissao_kg'])} de CO₂',
                        ),
                        isThreeLine: true,
                        trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                          IconButton(
                              icon: const Icon(Icons.edit),
                              onPressed: () => editar(item)),
                          IconButton(
                              icon: const Icon(Icons.delete),
                              onPressed: () => excluir(item)),
                        ]),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
