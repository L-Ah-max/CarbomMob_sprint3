import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../services/sessao.dart';
import '../services/util.dart';

/// Cards 20 (evolução das emissões) e 30 (meta de redução).
class EvolutionScreen extends StatefulWidget {
  const EvolutionScreen({super.key});

  @override
  State<EvolutionScreen> createState() => _EvolutionScreenState();
}

class _EvolutionScreenState extends State<EvolutionScreen> {
  late Future<List<dynamic>> futuro = carregar();

  Future<List<dynamic>> carregar() => Future.wait([
        ApiService.get('/impacto/${Sessao.usuarioId}'),
        ApiService.get('/metas/${Sessao.usuarioId}'),
      ]);

  Future<void> definirMeta() async {
    final c = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Meta deste mês'),
        content: TextField(
          controller: c,
          keyboardType: TextInputType.number,
          decoration:
              const InputDecoration(labelText: 'Limite de emissão (kg de CO₂)'),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancelar')),
          FilledButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Salvar')),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await ApiService.post('/metas', {
        'usuario_id': Sessao.usuarioId,
        'meta_kg': double.tryParse(c.text.replaceAll(',', '.')),
      });
      if (!mounted) return;
      setState(() => futuro = carregar());
    } catch (e) {
      if (!mounted) return;
      aviso(context, limpaErro(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Evolução e meta')),
      body: FutureBuilder<List<dynamic>>(
        future: futuro,
        builder: (context, s) {
          if (s.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (s.hasError) return Center(child: Text(limpaErro(s.error!)));
          final mensal = (s.data![0]['mensal'] as List?) ?? [];
          final meta = s.data![1] as Map;
          final emitido = num_(meta['emitido_kg']);
          final limite = meta['meta_kg'] == null ? null : num_(meta['meta_kg']);
          final maior = mensal.isEmpty
              ? 1.0
              : mensal.map((m) => num_(m['emissao'])).reduce((a, b) => a > b ? a : b);

          return ListView(padding: const EdgeInsets.all(16), children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('Meta de redução do mês',
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                  const SizedBox(height: 8),
                  if (limite == null)
                    const Text('Você ainda não definiu uma meta para este mês.')
                  else ...[
                    LinearProgressIndicator(
                      value: (emitido / limite).clamp(0.0, 1.0).toDouble(),
                      color: emitido > limite ? Colors.red : Colors.green,
                      minHeight: 10,
                    ),
                    const SizedBox(height: 8),
                    Text('${kg(emitido)} de ${kg(limite)}'
                        '${emitido > limite ? ' — meta ultrapassada' : ''}'),
                  ],
                  const SizedBox(height: 8),
                  OutlinedButton(
                      onPressed: definirMeta,
                      child: Text(limite == null ? 'Definir meta' : 'Alterar meta')),
                ]),
              ),
            ),
            const SizedBox(height: 12),
            const Text('Emissões por mês',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 8),
            if (mensal.isEmpty) const Text('Ainda não há deslocamentos registrados.'),
            ...mensal.map((m) {
              final v = num_(m['emissao']);
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Row(children: [
                  SizedBox(width: 70, child: Text('${m['mes']}')),
                  Expanded(
                    child: LinearProgressIndicator(
                        value: maior == 0 ? 0.0 : v / maior, minHeight: 18),
                  ),
                  const SizedBox(width: 8),
                  Text(kg(v)),
                ]),
              );
            }),
          ]);
        },
      ),
    );
  }
}
