import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../services/sessao.dart';

class ImpactScreen extends StatelessWidget {
  const ImpactScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Meu impacto')),
      body: FutureBuilder<Map<String, dynamic>>(
        future: ApiService.buscarImpacto(Sessao.usuarioId!),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(child: Text('${snapshot.error}'));
          }

          final dados = snapshot.data ?? {};
          final resumo = dados['resumo'] ?? {};
          final mensal = dados['mensal'] ?? [];

          return ListView(
            padding: const EdgeInsets.all(20),
            children: [
              Card(
                child: ListTile(
                  leading: const Icon(Icons.co2),
                  title: const Text('Emissão total'),
                  subtitle: Text(
                    '${resumo['total_emissao'] ?? 0} kg de CO₂',
                  ),
                ),
              ),
              Card(
                child: ListTile(
                  leading: const Icon(Icons.route),
                  title: const Text('Deslocamentos'),
                  subtitle: Text(
                    '${resumo['total_deslocamentos'] ?? 0}',
                  ),
                ),
              ),
              Card(
                child: ListTile(
                  leading: const Icon(Icons.analytics),
                  title: const Text('Média por deslocamento'),
                  subtitle: Text(
                    '${resumo['media_emissao'] ?? 0} kg de CO₂',
                  ),
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                'Evolução mensal',
                style: TextStyle(
                  fontSize: 21,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 10),
              ...mensal.map(
                (item) => ListTile(
                  title: Text(item['mes']),
                  trailing: Text('${item['emissao']} kg'),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
