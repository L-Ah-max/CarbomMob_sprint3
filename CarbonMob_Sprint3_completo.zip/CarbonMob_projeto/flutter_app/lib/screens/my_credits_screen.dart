import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../services/sessao.dart';
import '../services/util.dart';

/// Cards 24 (saldo), 16 (compensar), 29 (compras), 26 (comprovante), 17 (compensações).
class MyCreditsScreen extends StatelessWidget {
  const MyCreditsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Meus créditos'),
          bottom: const TabBar(tabs: [
            Tab(text: 'Saldo'),
            Tab(text: 'Compras'),
            Tab(text: 'Compensações'),
          ]),
        ),
        body: const TabBarView(children: [
          _SaldoTab(),
          _ComprasTab(),
          _CompensacoesTab(),
        ]),
      ),
    );
  }
}

class _SaldoTab extends StatefulWidget {
  const _SaldoTab();
  @override
  State<_SaldoTab> createState() => _SaldoTabState();
}

class _SaldoTabState extends State<_SaldoTab> {
  late Future<dynamic> futuro = ApiService.get('/saldo/${Sessao.usuarioId}');

  Future<void> compensar(Map item) async {
    final qtd = TextEditingController(text: '1');
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Compensar emissões'),
        content: TextField(
          controller: qtd,
          keyboardType: TextInputType.number,
          decoration: InputDecoration(
              labelText:
                  'Quantos créditos usar? (cada um compensa ${kg(item['compensacao_kg'])})'),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancelar')),
          FilledButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Confirmar')),
        ],
      ),
    );
    if (ok != true) return;
    try {
      final r = await ApiService.post('/compensacoes', {
        'usuario_id': Sessao.usuarioId,
        'credito_id': item['credito_id'],
        'quantidade': int.parse(qtd.text),
      });
      if (!mounted) return;
      aviso(context, 'Compensação confirmada: ${kg(r['kg_compensado'])} de CO₂.');
      setState(() => futuro = ApiService.get('/saldo/${Sessao.usuarioId}'));
    } catch (e) {
      if (!mounted) return;
      aviso(context, limpaErro(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<dynamic>(
      future: futuro,
      builder: (context, s) {
        if (s.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        if (s.hasError) return Center(child: Text(limpaErro(s.error!)));
        final lista = (s.data as List?) ?? [];
        if (lista.isEmpty) {
          return const Center(child: Text('Você ainda não possui créditos.'));
        }
        return ListView(
          padding: const EdgeInsets.all(12),
          children: lista.map((i) {
            final item = i as Map;
            return Card(
              child: ListTile(
                title: Text('${item['projeto']}'),
                subtitle: Text(
                    'Saldo: ${int_(item['saldo'])} crédito(s) • ${kg(int_(item['saldo']) * num_(item['compensacao_kg']))} de CO₂'),
                trailing: FilledButton(
                    onPressed: () => compensar(item),
                    child: const Text('Compensar')),
              ),
            );
          }).toList(),
        );
      },
    );
  }
}

class _ComprasTab extends StatelessWidget {
  const _ComprasTab();

  Future<void> comprovante(BuildContext context, int id) async {
    try {
      final c = await ApiService.get(
          '/compras/detalhe/$id?usuario_id=${Sessao.usuarioId}');
      if (!context.mounted) return;
      showDialog<void>(
        context: context,
        builder: (_) => AlertDialog(
          title: Text('Comprovante #${c['id']}'),
          content: Text(
            'Comprador: ${c['comprador']}\n'
            'Data: ${dataBr(c['data_compra'])}\n'
            'Projeto: ${c['projeto']} (${c['empresa']})\n'
            'Quantidade: ${c['quantidade']}\n'
            'Preço unitário: ${reais(c['preco'])}\n'
            'CO₂ compensável: ${kg(int_(c['quantidade']) * num_(c['compensacao_kg']))}\n'
            'Total: ${reais(c['valor_total'])}',
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Fechar')),
          ],
        ),
      );
    } catch (e) {
      aviso(context, limpaErro(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<dynamic>(
      future: ApiService.get('/compras/${Sessao.usuarioId}'),
      builder: (context, s) {
        if (s.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        if (s.hasError) return Center(child: Text(limpaErro(s.error!)));
        final lista = (s.data as List?) ?? [];
        if (lista.isEmpty) {
          return const Center(child: Text('Nenhuma compra realizada.'));
        }
        return ListView(
          padding: const EdgeInsets.all(12),
          children: lista.map((i) {
            final c = i as Map;
            return Card(
              child: ListTile(
                title: Text('Compra #${c['id']} • ${c['projeto']}'),
                subtitle: Text(
                    '${dataBr(c['data_compra'])} • ${c['quantidade']} crédito(s) • ${reais(c['valor_total'])}'),
                trailing: TextButton(
                    onPressed: () => comprovante(context, c['id'] as int),
                    child: const Text('Comprovante')),
              ),
            );
          }).toList(),
        );
      },
    );
  }
}

class _CompensacoesTab extends StatelessWidget {
  const _CompensacoesTab();

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<dynamic>(
      future: ApiService.get('/compensacoes/${Sessao.usuarioId}'),
      builder: (context, s) {
        if (s.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        if (s.hasError) return Center(child: Text(limpaErro(s.error!)));
        final lista = (s.data as List?) ?? [];
        if (lista.isEmpty) {
          return const Center(child: Text('Nenhuma compensação realizada.'));
        }
        return ListView(
          padding: const EdgeInsets.all(12),
          children: lista.map((i) {
            final c = i as Map;
            return Card(
              child: ListTile(
                title: Text('${kg(c['kg_compensado'])} de CO₂ compensados'),
                subtitle: Text(
                    '${dataBr(c['data_compensacao'])} • ${c['quantidade']} crédito(s) • ${c['projeto']}'),
              ),
            );
          }).toList(),
        );
      },
    );
  }
}
